# Bot Jualan Affiliate (APK Android)

Cara jadi APK (kurang dari 10 menit, tanpa coding):

1. Install **Android Studio** (gratis): https://developer.android.com/studio
2. Extract zip ini, lalu di Android Studio: **File > Open** → pilih folder `AffiliateSellerBot`
3. Tunggu Gradle sync selesai (butuh internet, ~2-5 menit pertama)
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. Klik **locate** → file `app-debug.apk` → kirim ke HP & install ✅

Opsional sebelum build:
- Edit produk di `app/src/main/java/com/affiliate/bot/MainActivity.kt` → ubah `katalogDefault`
- Isi affiliate tag & nama toko bisa juga langsung dari dalam aplikasi

Fitur:
- Simpan nama toko + affiliate tag (tersimpan permanen)
- 1-tap buat caption promo produk (otomatis tersalin)
- 1-tap balasan chat cepat: sapaan, ongkir, garansi, closing
