package com.affiliate.bot

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp

data class Produk(
    val nama: String,
    val kategori: String,
    val harga: String,
    val hargaCoret: String,
    val link: String,
    val poinJual: String
)

// Ganti dengan produk dari dashboard Shopee Affiliate
val katalogDefault = listOf(
    Produk("Serum Niacinamide 10%", "Skincare", "Rp27.500", "Rp89.000",
        "https://shopee.co.id/serum", "Mencerahkan & kontrol minyak"),
    Produk("Earbud TWS Bass+", "Gadget", "Rp38.900", "Rp129.000",
        "https://shopee.co.id/earbud", "Baterai 24 jam, garansi 6 bulan"),
    Produk("Pouch Organizer Travel", "Fashion", "Rp15.000", "Rp45.000",
        "https://shopee.co.id/pouch", "Anti air, muat banyak")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(this) }
    }
}

@Composable
fun App(ctx: Context) {
    val prefs = ctx.getSharedPreferences("bot", Context.MODE_PRIVATE)
    var tag by remember { mutableStateOf(prefs.getString("tag", "") ?: "") }
    var toko by remember { mutableStateOf(prefs.getString("toko", "Toko Kami") ?: "Toko Kami") }
    var hasil by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current

    fun linkAff(p: Produk) =
        if (p.link.contains("?")) "${p.link}&affiliate=$tag" else "${p.link}?affiliate=$tag"

    fun captionProduk(p: Produk) = """
        |🔥 ${p.nama}
        |💰 ${p.harga} <s>${p.hargaCoret}</s>
        |💡 ${p.poinJual}
        |✅ Gratis ongkir min. Rp30.000 | Garansi resmi
        |
        |🛒 Checkout di sini ya kak:
        |${linkAff(p)}
        |
        |Stok terbatas, jangan sampai kehabisan!
    """.trimMargin()

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text("🤖 Bot Jualan Affiliate", style = MaterialTheme.typography.headlineSmall)
                Text("Generator caption & balasan cepat", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = toko, onValueChange = { toko = it; prefs.edit().putString("toko", it).apply() },
                    label = { Text("Nama toko") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = tag, onValueChange = { tag = it; prefs.edit().putString("tag", it).apply() },
                    label = { Text("Affiliate tag") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))

                Text("Produk — tap untuk buat caption", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                katalogDefault.forEach { p ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.nama, style = MaterialTheme.typography.titleSmall)
                            Text("${p.kategori} · ${p.harga}", style = MaterialTheme.typography.bodySmall)
                            Row {
                                TextButton(onClick = {
                                    hasil = captionProduk(p)
                                    clipboard.setText(AnnotatedString(hasil))
                                }) { Text("📋 Caption promo") }
                                TextButton(onClick = {
                                    hasil = "Halo kak! 👋 Lagi cari ${p.nama}? Best seller di $toko, " +
                                        "harga cuma ${p.harga} aja. Mau dibantu checkout? 🛒\n${linkAff(p)}"
                                    clipboard.setText(AnnotatedString(hasil))
                                }) { Text("💬 Balasan chat") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                Text("Balasan cepat", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                listOf(
                    "Sapaan" to "Halo kak! 👋 Selamat datang di $toko. Ada yang bisa dibantu carikan hari ini? Kami jago cariin barang promo & gratis ongkir! 🛍️",
                    "Tanya ongkir" to "Gratis ongkir min. belanja Rp30.000 kak ✅ Same-day untuk Jabodetabek. Packing bubble wrap + safety packing ya!",
                    "Tanya garansi" to "Tenang kak, semua produk bergaransi 6–12 bulan. Ada cacat? Retur 7 hari, refund penuh via Shopee 👍",
                    "Closing" to "Mau dibantu checkout sekarang kak? Stok lagi tipis, kalau lewat flash sale sayang banget! 🥰"
                ).forEach { (judul, isi) ->
                    OutlinedButton(
                        onClick = { hasil = isi; clipboard.setText(AnnotatedString(isi)) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) { Text("📋 $judul") }
                }
                Spacer(Modifier.height(16.dp))

                if (hasil.isNotEmpty()) {
                    Text("Hasil (sudah tersalin ke clipboard)", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Text(hasil, Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Langsung tempel di WhatsApp / Telegram / komen Shopee",
                        style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}
